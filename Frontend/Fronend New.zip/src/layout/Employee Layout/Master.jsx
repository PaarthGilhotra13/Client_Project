import { Outlet, useNavigate } from "react-router-dom";

export default function Master() {
    return (
        <>
            {/* <Header />
            <EmployeeSidebar />
            <Outlet /> */}
        </>
    )
}